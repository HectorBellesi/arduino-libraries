#ifdef __AVR_ATmega2560__

#ifndef timer5_h
#define timer5_h


#include <avr/io.h>
unsigned char ucDesbordamientos;


// interrupt to get coverflow of counter (carry bit)
ISR(TIMER5_OVF_vect)
{
 ucDesbordamientos++;
 TIFR5 |= (0 << TOV5);
}

#endif

#else
  #error Oops! Trying to include timer5 on another device, different that Mega2560?
#endif
